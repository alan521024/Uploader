﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DoubleX.Upload
{
    public enum EnumTaskFileStatus
    {
        默认 = 0,
        待上传 = 1,
        上传中 = 2,
        完成 = 3,
        出错 = 4
    }
}

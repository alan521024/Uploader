﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DoubleX.Upload
{
    /// <summary>
    /// 文件路径任务类型
    /// </summary>
    public enum EnumPathType
    {
        默认 = 0,
        文件夹 = 1,
        文件 = 2
    }
}
